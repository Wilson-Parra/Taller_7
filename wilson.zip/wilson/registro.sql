CREATE DATABASE registro;
USE registro;

CREATE TABLE users_tbl (
    user_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    user_firstname VARCHAR(40) NOT NULL,
    user_lastname VARCHAR(40) NOT NULL,
    user_email VARCHAR(60) NOT NULL,
    user_password VARBINARY(256)
);

create table category_tbl(
category_id int not null primary key auto_increment,
category_name VARCHAR(40) not null
);
create table product_tbl(
product_id int not null primary key auto_increment,
product_name VARCHAR(40) not null,
product_value int null,
category_id int not null
);


alter table product_tbl 
add constraint category_id
foreign key (category_id)
references category_tbl (category_id);

INSERT INTO users_tbl (user_firstname, user_lastname, user_email, user_password) 
VALUES (UPPER('wilson'), UPPER('parra'), 'wilsonp1454@correo.com', AES_ENCRYPT('wilson1025527142', '$2a$15$abPL48wI.iIbD/i6QmTH/uvoBPXz6ZnaodITLJnRE5yh2CardeQBi'));
INSERT INTO users_tbl (user_firstname, user_lastname, user_email, user_password) 
VALUES (UPPER('stick'), UPPER('urquijo'), 'stickurquijo02@gmail.com', AES_ENCRYPT('stick0914', '$2a$15$abPL48wI.iIbD/i6QmTH/uvoBPXz6ZnaodITLJnRE5yh2CardeQBi'));

SELECT *, CAST(AES_DECRYPT(user_password, '$2a$15$abPL48wI.iIbD/i6QmTH/uvoBPXz6ZnaodITLJnRE5yh2CardeQBi') AS CHAR(50)) AS end_data 
FROM users_tbl 
WHERE user_id = 1;
SELECT *, CAST(AES_DECRYPT(user_password, '$2a$15$abPL48wI.iIbD/i6QmTH/uvoBPXz6ZnaodITLJnRE5yh2CardeQBi') AS CHAR(50)) AS end_data 
FROM users_tbl 
WHERE user_id = 3;

select * from users_tbl;
SELECT * FROM category_tbl;
SELECT * FROM product_tbl;
DROP DATABASE registro;
